
public enum tipoEstado {
    RESERVADO,
    LIBRE
}
