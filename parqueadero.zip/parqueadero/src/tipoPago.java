
public enum tipoPago {
    TARJETA_CREDITO,
    TRANSFERENCIA_BANCARIA,
    PAYPAL,
    EFECTIVO
}
