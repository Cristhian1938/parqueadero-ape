public interface INotificable {
    String enviarNotificacion();
    String obtenerNotificaciones();
}
