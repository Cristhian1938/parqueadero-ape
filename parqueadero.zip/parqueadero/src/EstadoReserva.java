
public enum EstadoReserva {
    PENDIENTE,
    CONFIRMADO,
    ACTIVA,
    FINALIZADA
}
